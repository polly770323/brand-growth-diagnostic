
# Brand Growth Diagnostic Tool — MVP v0.1

這是一個給品牌 / FMCG / Consumer Business 使用的公開資料品牌診斷 MVP。

## 核心框架

工具不是直接「替品牌下結論」，而是依照：

**Signal → Observation → Hypothesis → Recommended Test**

來協助顧問整理公開數據訊號。

目前包含 6 個維度：

1. Demand / Search
2. Digital Strength
3. Product & Pricing
4. Channel Coverage
5. Marketing Activity
6. Consumer Voice

最後產出：
- Brand Growth Radar
- Key Signals
- Growth Hypotheses
- Recommended Tests
- 可下載 Markdown Report

## 執行方式

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 第一版使用方式

v0.1 採「手動 / 半自動輸入」：
- Google Trends：匯出 CSV 後填入需求指標
- Similarweb：填入公開 / 付費查到的網站資料
- Meta Ad Library：人工觀察 Active Ads / 素材比例
- TikTok Creative Center：人工紀錄趨勢 / 素材
- 官網與電商：人工填 SKU、價格與通路
- Google Maps / 電商評論：人工整理評分、正負向訊號

這樣做的目的是先驗證「診斷框架是否有商業價值」，再決定哪些資料值得串 API。

## 下一版建議

v0.2:
- Google Trends CSV 上傳
- 競品比較
- 自動計算 Share of Search
- Channel Matrix
- Product Pricing Ladder

v0.3:
- LLM 自動摘要 Consumer Voice
- 自動抓品牌官網 SKU
- 自動分類廣告素材
- PDF Consulting Report

v1.0:
- 品牌資料庫
- 多品牌 benchmark
- 帳號 / 專案管理
- 顧問報告模板
- Fractional Advisor workflow
