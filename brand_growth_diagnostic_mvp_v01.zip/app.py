
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

st.set_page_config(page_title="Brand Growth Diagnostic", layout="wide")

st.title("Brand Growth Diagnostic Tool")
st.caption("Public-signal based brand diagnostic framework for commercial growth consulting")

# ---------- Helpers ----------
def clamp(v, lo=0, hi=100):
    return max(lo, min(hi, float(v)))

def pct_change(new, old):
    if old in (0, None) or pd.isna(old):
        return 0
    return (new-old)/old*100

def score_from_growth(growth):
    # simple MVP mapping
    return clamp(50 + growth * 1.5)

def safe_mean(vals):
    vals = [v for v in vals if v is not None and not pd.isna(v)]
    return float(np.mean(vals)) if vals else 0

def radar_chart(scores):
    labels = list(scores.keys())
    values = list(scores.values())
    angles = np.linspace(0, 2*np.pi, len(labels), endpoint=False).tolist()
    values += values[:1]
    angles += angles[:1]
    fig = plt.figure(figsize=(6, 6))
    ax = plt.subplot(111, polar=True)
    ax.plot(angles, values, linewidth=2)
    ax.fill(angles, values, alpha=0.15)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    ax.set_yticks([20,40,60,80,100])
    ax.set_ylim(0,100)
    return fig

def diagnose(scores):
    d = scores["Demand"]
    dig = scores["Digital"]
    m = scores["Marketing"]
    p = scores["Product"]
    c = scores["Channel"]
    v = scores["Consumer Voice"]

    hypotheses = []
    tests = []

    if d >= 65 and c < 50:
        hypotheses.append("Distribution constraint：市場需求不弱，但通路覆蓋相對不足，成長瓶頸可能在可得性。")
        tests.append("選 1 個新通路做 6–8 週小規模上架測試，追蹤 sell-through、CAC、重購與毛利。")

    if d < 45 and m < 55:
        hypotheses.append("Awareness / Demand constraint：品牌需求訊號偏弱，且行銷活躍度不足。")
        tests.append("用 2–3 種核心訴求做短週期 awareness 測試，觀察搜尋量與品牌字成長。")

    if d >= 55 and dig < 50:
        hypotheses.append("Digital conversion gap：已有需求，但數位承接能力可能不足。")
        tests.append("檢查官網 PDP、流量來源與轉換漏斗，優先優化 Hero SKU landing page。")

    if p < 50:
        hypotheses.append("Product architecture gap：價格階梯、SKU 結構或 Hero Product 定義可能不夠清楚。")
        tests.append("重整 Entry / Core / Premium 價格帶，明確設定 Hero SKU 與組合包策略。")

    if v < 50:
        hypotheses.append("Experience / Retention risk：消費者口碑訊號偏弱，可能影響重購與推薦。")
        tests.append("把負評分成產品、服務、價格、物流四類，優先修正高頻且高影響問題。")

    if m >= 70 and d < 50:
        hypotheses.append("Marketing efficiency risk：行銷活動高，但需求訊號沒有同步成長。")
        tests.append("把素材分成品牌／功能／促銷／UGC 四類，重算各類帶來的搜尋與轉換增量。")

    if not hypotheses:
        hypotheses.append("目前沒有單一明顯短板，較適合從競品差距與成長白地切入。")
        tests.append("選 1 個競品明顯領先的維度，設計 30 天驗證實驗。")

    return hypotheses, tests

# ---------- Sidebar ----------
st.sidebar.header("Brand Setup")
brand = st.sidebar.text_input("品牌名稱", "Example Brand")
category = st.sidebar.text_input("品類", "Food / FMCG")
competitors = st.sidebar.text_area("競品（每行一個）", "Competitor A\nCompetitor B\nCompetitor C").splitlines()

st.sidebar.markdown("---")
st.sidebar.caption("MVP v0.1：先用手動 / 半自動公開數據輸入驗證框架，再串 API。")

tabs = st.tabs([
    "1. Demand",
    "2. Digital",
    "3. Product & Price",
    "4. Channel",
    "5. Marketing",
    "6. Consumer Voice",
    "7. Diagnosis"
])

# ---------- Demand ----------
with tabs[0]:
    st.subheader("Demand / Search Signals")
    col1, col2, col3 = st.columns(3)
    with col1:
        search_3m = st.number_input("最近 3 個月搜尋指數", 0.0, 100.0, 65.0)
    with col2:
        search_prev3m = st.number_input("前 3 個月搜尋指數", 0.0, 100.0, 55.0)
    with col3:
        category_share = st.number_input("Share of Search (%)", 0.0, 100.0, 22.0)

    seasonality = st.slider("季節性依賴程度（0=低、100=高）", 0, 100, 50)
    demand_growth = pct_change(search_3m, search_prev3m)
    demand_score = clamp(score_from_growth(demand_growth) * 0.65 + category_share * 0.35)
    st.metric("Demand Momentum", f"{demand_growth:+.1f}%")
    st.progress(int(demand_score))
    st.caption("資料可先從 Google Trends 匯出後填入。")

# ---------- Digital ----------
with tabs[1]:
    st.subheader("Digital Strength")
    c1, c2, c3, c4 = st.columns(4)
    visits = c1.number_input("月網站訪問量（估算）", min_value=0, value=30000)
    organic = c2.number_input("Organic %", 0.0, 100.0, 35.0)
    direct = c3.number_input("Direct %", 0.0, 100.0, 30.0)
    paid = c4.number_input("Paid %", 0.0, 100.0, 15.0)
    bounce = st.slider("Bounce Rate (%)", 0, 100, 48)
    digital_score = clamp(
        min(visits/1000, 40) +
        organic*0.25 +
        direct*0.25 +
        max(0, (70-bounce))*0.5
    )
    st.progress(int(digital_score))

# ---------- Product ----------
with tabs[2]:
    st.subheader("Product & Pricing Architecture")
    c1, c2, c3, c4 = st.columns(4)
    sku_count = c1.number_input("SKU 數量", 1, 500, 18)
    entry_price = c2.number_input("Entry Price", 0, 100000, 199)
    core_price = c3.number_input("Core Price", 0, 100000, 499)
    premium_price = c4.number_input("Premium Price", 0, 100000, 999)
    hero_defined = st.selectbox("是否有明確 Hero SKU", ["有", "沒有", "不確定"])
    bundle_ratio = st.slider("組合包 / 禮盒占比 (%)", 0, 100, 30)

    ladder_ok = 1 if entry_price < core_price < premium_price else 0
    product_score = 35 + ladder_ok*25 + (20 if hero_defined=="有" else 8 if hero_defined=="不確定" else 0) + min(bundle_ratio,40)*0.5
    product_score = clamp(product_score)
    st.progress(int(product_score))

# ---------- Channel ----------
with tabs[3]:
    st.subheader("Channel Coverage")
    channels = [
        "品牌官網","蝦皮","momo","PChome","7-ELEVEN","全家","Costco",
        "量販 / 超市","百貨","機場 / Travel Retail","B2B / Corporate Gift","海外通路"
    ]
    selected = st.multiselect("目前已有通路", channels, default=["品牌官網","蝦皮","B2B / Corporate Gift"])
    strategic = st.multiselect("你認為應該進入的策略通路", channels, default=["momo","全家","海外通路"])
    channel_score = clamp(len(selected)/len(channels)*100)
    gaps = [c for c in strategic if c not in selected]
    st.metric("Channel Coverage", f"{channel_score:.0f}/100")
    if gaps:
        st.warning("Potential channel gaps: " + "、".join(gaps))

# ---------- Marketing ----------
with tabs[4]:
    st.subheader("Marketing Activity")
    active_ads = st.number_input("Active Ads / Creatives", 0, 1000, 20)
    promo_pct = st.slider("促銷導購素材占比 (%)", 0, 100, 45)
    brand_pct = st.slider("品牌形象素材占比 (%)", 0, 100, 20)
    ugc_pct = st.slider("UGC / KOL 素材占比 (%)", 0, 100, 20)
    new_product_pct = st.slider("新品素材占比 (%)", 0, 100, 15)

    mix_penalty = abs(100 - (promo_pct+brand_pct+ugc_pct+new_product_pct))
    marketing_score = clamp(min(active_ads*2.2,60) + (40-max(mix_penalty,0)*0.8))
    st.metric("Marketing Activity", f"{marketing_score:.0f}/100")
    if promo_pct >= 60:
        st.info("目前素材組合偏 Conversion / Promotion，可再檢查 Brand-building 是否不足。")

# ---------- Consumer ----------
with tabs[5]:
    st.subheader("Consumer Voice")
    c1, c2, c3 = st.columns(3)
    rating = c1.number_input("平均星等", 1.0, 5.0, 4.3, step=0.1)
    review_count = c2.number_input("評論數", 0, 1000000, 1200)
    positive_ratio = c3.slider("正向評論估計 (%)", 0, 100, 78)

    positive_terms = st.text_area("高頻正向關鍵字", "好吃\n方便\n送禮")
    negative_terms = st.text_area("高頻負向關鍵字", "價格高\n包裝\n等待時間")

    voice_score = clamp((rating/5*50) + positive_ratio*0.4 + min(review_count/5000*10,10))
    st.metric("Consumer Voice", f"{voice_score:.0f}/100")

# ---------- Diagnosis ----------
with tabs[6]:
    st.subheader(f"{brand} — Brand Growth Diagnostic")

    scores = {
        "Demand": round(demand_score,1),
        "Digital": round(digital_score,1),
        "Marketing": round(marketing_score,1),
        "Product": round(product_score,1),
        "Channel": round(channel_score,1),
        "Consumer Voice": round(voice_score,1),
    }

    c1, c2 = st.columns([1,1])
    with c1:
        st.pyplot(radar_chart(scores))
    with c2:
        score_df = pd.DataFrame({"Dimension":scores.keys(),"Score":scores.values()})
        st.dataframe(score_df, hide_index=True, use_container_width=True)

    st.markdown("### Key Signals")
    demand_signal = "上升" if demand_growth > 5 else "下降" if demand_growth < -5 else "持平"
    st.write(f"- Demand Momentum：**{demand_signal} ({demand_growth:+.1f}%)**")
    st.write(f"- Channel Coverage：**{channel_score:.0f}/100**")
    st.write(f"- Consumer Voice：**{voice_score:.0f}/100**")
    st.write(f"- Marketing Activity：**{marketing_score:.0f}/100**")

    hypotheses, tests = diagnose(scores)

    st.markdown("### Growth Hypotheses")
    for h in hypotheses:
        st.write("• " + h)

    st.markdown("### Recommended Tests")
    for t in tests:
        st.write("• " + t)

    st.markdown("### Consultant Notes")
    notes = st.text_area(
        "加入你的顧問判斷",
        "公開數據只能作為方向訊號；正式建議前仍需驗證內部營收、毛利、轉換率、通路 sell-through 與回購資料。"
    )

    report = f"""
# {brand} — Brand Growth Diagnostic

Category: {category}

## Scores
{chr(10).join([f"- {k}: {v}/100" for k,v in scores.items()])}

## Key Signals
- Demand Momentum: {demand_growth:+.1f}%
- Channel Coverage: {channel_score:.0f}/100
- Consumer Voice: {voice_score:.0f}/100
- Marketing Activity: {marketing_score:.0f}/100

## Growth Hypotheses
{chr(10).join([f"- {h}" for h in hypotheses])}

## Recommended Tests
{chr(10).join([f"- {t}" for t in tests])}

## Consultant Notes
{notes}

Disclaimer: This diagnostic is based on public / estimated signals and should be used as decision support, not as a substitute for internal business data.
"""
    st.download_button(
        "Download Markdown Report",
        data=report,
        file_name=f"{brand.replace(' ','_')}_brand_diagnostic.md",
        mime="text/markdown"
    )
